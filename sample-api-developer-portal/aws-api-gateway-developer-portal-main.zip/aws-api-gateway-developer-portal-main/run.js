'use strict'

require('./scripts/run.js')
