'use strict'

module.exports = {
  root: true,
  extends: 'standard',
  env: {
    jest: true
  }
}